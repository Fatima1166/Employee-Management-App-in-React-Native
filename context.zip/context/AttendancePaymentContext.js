import React, { createContext, useContext, useEffect, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { EmployeeContext } from './EmployeeContext';

export const AttendancePaymentContext = createContext();

const STORAGE_KEY = '@attendance_payment_records';

export const AttendancePaymentProvider = ({ children }) => {
  const { employees, updateEmployee } = useContext(EmployeeContext);
  const [records, setRecords] = useState([]);

  // Load from AsyncStorage on mount
  useEffect(() => {
    const loadRecords = async () => {
      try {
      
        const jsonValue = await AsyncStorage.getItem(STORAGE_KEY);
        if (jsonValue != null) {
          setRecords(JSON.parse(jsonValue));
        } else {
          // Sync initially with employees
          setRecords(
            employees.map((emp) => ({
              id: emp.id,
              name: emp.name,
              attendanceRecords: [],
              latestAttendance: '',
              salary: Number(emp.salary) || 0,
              bonus: 0,
              advance: 0,
            }))
          );
        }
      } catch (e) {
        console.error('Failed to load attendance/payment records', e);
      }
    };

    loadRecords();
  }, []);

  // Save to AsyncStorage whenever records change
  useEffect(() => {
    const saveRecords = async () => {
      try {
        await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(records));
      } catch (e) {
        console.error('Failed to save attendance/payment records', e);
      }
    };

    if (records.length) saveRecords();
  }, [records]);

  // Sync new employees in records when employees list changes
  useEffect(() => {
    setRecords((prev) => {
      // Add new employees to records if missing, keep existing
      return employees.map((emp) => {
        const existing = prev.find((r) => r.id === emp.id);
        return (
          existing || {
            id: emp.id,
            name: emp.name,
            attendanceRecords: [],
            latestAttendance: '',
            salary: Number(emp.salary) || 0,
            bonus: 0,
            advance: 0,
          }
        );
      });
    });
  }, [employees]);

  // Add an attendance record for an employee
  const addAttendanceRecord = (employeeId, attendanceStatus, date) => {
    setRecords((prev) =>
      prev.map((rec) => {
        if (rec.id === employeeId) {
          const newRecord = { date, status: attendanceStatus };
          return {
            ...rec,
            attendanceRecords: [...rec.attendanceRecords, newRecord],
            latestAttendance: attendanceStatus,
          };
        }
        return rec;
      })
    );
  };

  // Mark attendance (just a helper to call addAttendanceRecord with current date)
  const markAttendance = (employeeId, status) => {
    const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD format
    addAttendanceRecord(employeeId, status, today);
  };

  // Update payment info for an employee
  const updatePayment = (employeeId, { salary, bonus, advance }) => {
    setRecords((prev) =>
      prev.map((rec) =>
        rec.id === employeeId
          ? {
              ...rec,
              salary: salary !== undefined ? salary : rec.salary,
              bonus: bonus !== undefined ? bonus : rec.bonus,
              advance: advance !== undefined ? advance : rec.advance,
            }
          : rec
      )
    );
  };

  // Reset all records (attendance and payments)
  const resetAll = () => {
    setRecords(
      employees.map((emp) => ({
        id: emp.id,
        name: emp.name,
        attendanceRecords: [],
        latestAttendance: '',
        salary: Number(emp.salary) || 0,
        bonus: 0,
        advance: 0,
      }))
    );
  };

  return (
    <AttendancePaymentContext.Provider
      value={{
        records,
        markAttendance,
        addAttendanceRecord,
        updatePayment,
        resetAll,
      }}
    >
      {children}
    </AttendancePaymentContext.Provider>
  );
};
