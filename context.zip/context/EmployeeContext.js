import React, { createContext, useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

export const EmployeeContext = createContext();

const STORAGE_KEY = '@employees_data';

export const EmployeeProvider = ({ children }) => {
  const [employees, setEmployees] = useState([]);

  // Load employees from AsyncStorage on mount
  useEffect(() => {
    const loadEmployees = async () => {
      try {
        const jsonValue = await AsyncStorage.getItem(STORAGE_KEY);
        if (jsonValue != null) {
          setEmployees(JSON.parse(jsonValue));
        } else {
          // Default employees if none saved yet
          setEmployees([
            {
              id: '1',
              name: 'Ali',
              email: 'ali11@gmail.com',
              phone: '1234567890',
              department: 'HR',
              position: 'Manager',
              joinDate: '2023-01-01',
              salary: '60000',
              attendance: { present: 20, absent: 2, halfday: 3, holiday: 4 },
            },
            {
              id: '2',
              name: 'Ahmed',
              email: 'ahmed33@example.com',
              phone: '9876543210',
              department: 'Finance',
              position: 'Accountant',
              joinDate: '2022-05-10',
              salary: '50000',
              attendance: { present: 10, absent: 2, halfday: 1, holiday: 0 },
            },
          ]);
        }
      } catch (e) {
        console.error('Failed to load employees', e);
      }
    };

    loadEmployees();
  }, []);

  // Save employees to AsyncStorage whenever it changes
  useEffect(() => {
    const saveEmployees = async () => {
      try {
        await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(employees));
      } catch (e) {
        console.error('Failed to save employees', e);
      }
    };

    if (employees.length) saveEmployees();
  }, [employees]);

  // Add a new employee
  const addEmployee = (employee) => {
    setEmployees((prev) => [
      ...prev,
      {
        ...employee,
        id: Date.now().toString(),
        salary: employee.salary || '0',
        attendance: {
          present: 0,
          absent: 0,
          halfday: 0,
          holiday: 0,
        },
      },
    ]);
  };

  // Delete employee by id
  const deleteEmployee = (id) => {
    setEmployees((prev) => prev.filter((emp) => emp.id !== id));
  };

  // Update employee data
  const updateEmployee = (updatedEmp) => {
    setEmployees((prev) =>
      prev.map((emp) => (emp.id === updatedEmp.id ? { ...emp, ...updatedEmp } : emp))
    );
  };

  // Mark attendance (increment count for a given status)
  const markAttendance = (employeeId, status) => {
    setEmployees((prev) =>
      prev.map((emp) =>
        emp.id === employeeId
          ? {
              ...emp,
              attendance: {
                ...emp.attendance,
                [status]: (emp.attendance[status] || 0) + 1,
              },
            }
          : emp
      )
    );
  };

  return (
    <EmployeeContext.Provider
      value={{
        employees,
        addEmployee,
        deleteEmployee,
        updateEmployee,
        markAttendance,
      }}
    >
      {children}
    </EmployeeContext.Provider>
  );
};
