import React from 'react';
import { View, Text, Image, StyleSheet, ScrollView } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient'; // For background gradient

// Functional component for About Us screen
const AboutUsScreen = () => {
  return (
    // Gradient background wrapper
    <LinearGradient colors={['#f2f6fc', '#e3ebf6']} style={styles.gradient}>
      {/* Scrollable content container */}
      <ScrollView contentContainerStyle={styles.container}>
        
        {/* Heading */}
        <Text style={styles.heading}>Meet Our Leadership Team</Text>

        {/* Card for President */}
        <View style={styles.card}>
          <Image source={require('../assets/A.png')} style={styles.image} />
          <Text style={styles.name}>Mr. Ahad</Text>
          <Text style={styles.role}>President</Text>
          <Text style={styles.bio}>
            With over 20 years of industry experience, Mr. Ahad guides TechNova Solutions with a strategic vision and a strong focus on innovation and excellence.
          </Text>
        </View>

        {/* Card for Vice President */}
        <View style={styles.card}>
          <Image source={require('../assets/B.png')} style={styles.image} />
          <Text style={styles.name}>Ms. Zara Ray</Text>
          <Text style={styles.role}>Vice President</Text>
          <Text style={styles.bio}>
            Ms. Ray excels in business development and strategic partnerships, driving global client success through exceptional relationship management.
          </Text>
        </View>

        {/* Card for Department Head */}
        <View style={styles.card}>
          <Image source={require('../assets/C.png')} style={styles.image} />
          <Text style={styles.name}>Mr. Steve Khan</Text>
          <Text style={styles.role}>Department Head</Text>
          <Text style={styles.bio}>
            As the head of engineering, Mr. Khan leads multiple development teams and ensures high-quality delivery of all technical projects.
          </Text>
        </View>
      </ScrollView>
    </LinearGradient>
  );
};

export default AboutUsScreen;

// Styles for the About Us screen
const styles = StyleSheet.create({
  gradient: {
    flex: 1, // Full screen height
  },
  container: {
    padding: 20,
    alignItems: 'center', // Center all items horizontally
  },
  heading: {
    fontSize: 26,
    fontWeight: 'bold',
    color: '#2c3e50',
    marginBottom: 30,
    textAlign: 'center',
  },
  card: {
    backgroundColor: '#fff',
    borderRadius: 20,
    padding: 20,
    alignItems: 'center',
    marginBottom: 25,
    width: '100%',
    maxWidth: 360,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 6, // Android shadow
  },
  image: {
    width: 110,
    height: 110,
    borderRadius: 55, // Makes image circular
    marginBottom: 15,
    borderWidth: 2,
    borderColor: '#dcdde1',
  },
  name: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#34495e',
  },
  role: {
    fontSize: 16,
    color: '#7f8c8d',
    marginBottom: 10,
    fontStyle: 'italic',
  },
  bio: {
    fontSize: 15,
    color: '#2c3e50',
    textAlign: 'center',
    lineHeight: 22,
  },
});
