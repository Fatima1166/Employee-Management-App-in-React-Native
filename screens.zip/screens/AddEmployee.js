import React, { useContext, useState } from 'react';
import {
  View,
  StyleSheet,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  TouchableWithoutFeedback,
  Keyboard,
  Alert,
} from 'react-native';
import { TextInput, Button, Card, IconButton } from 'react-native-paper';
import { SafeAreaView } from 'react-native-safe-area-context';
import DateTimePicker from '@react-native-community/datetimepicker';
import { EmployeeContext } from '../context/EmployeeContext';

const AddEmployee = ({ navigation }) => {
  const { addEmployee } = useContext(EmployeeContext);
  const [form, setForm] = useState({
    name: '',
    email: '',
    phone: '',
    department: '',
    position: '',
    joinDate: '',
    salary: '',
  });

  const [showDatePicker, setShowDatePicker] = useState(false);
  const [selectedDate, setSelectedDate] = useState(null);

  const handleChange = (key, value) => {
    setForm({ ...form, [key]: value });
  };

  const onChangeDate = (event, date) => {
    setShowDatePicker(Platform.OS === 'ios');
    if (date) {
      setSelectedDate(date);
      const formattedDate = date.toLocaleDateString();
      setForm({ ...form, joinDate: formattedDate });
    }
  };

  const handleSubmit = () => {
    const isFormIncomplete = Object.values(form).some((field) => field.trim() === '');
    if (isFormIncomplete) {
      Alert.alert('Incomplete Form', 'Please fill in all fields before submitting.');
    } else {
      addEmployee({ ...form, salary: parseFloat(form.salary) });
      Alert.alert('Success', 'Employee added successfully!', [
        {
          text: 'OK',
          onPress: () => navigation.goBack(),
        },
      ]);
    }
  };

  return (
    <SafeAreaView style={styles.wrapper}>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        style={{ flex: 1 }}
      >
        <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
          <ScrollView contentContainerStyle={styles.container} keyboardShouldPersistTaps="handled">
            <Card style={styles.card} elevation={5}>
              <Card.Title title="Add New Employee" titleStyle={styles.cardTitle} />
              <Card.Content>
                <View style={styles.inputGroup}>
                  <IconButton icon="account" size={20} color="#244a85" />
                  <TextInput
                    label="Name"
                    value={form.name}
                    onChangeText={(value) => handleChange('name', value)}
                    mode="outlined"
                    style={styles.input}
                  />
                </View>
                <View style={styles.inputGroup}>
                  <IconButton icon="email" size={20} color="#244a85" />
                  <TextInput
                    label="Email"
                    value={form.email}
                    onChangeText={(value) => handleChange('email', value)}
                    mode="outlined"
                    style={styles.input}
                    keyboardType="email-address"
                  />
                </View>
                <View style={styles.inputGroup}>
                  <IconButton icon="phone" size={20} color="#244a85" />
                  <TextInput
                    label="Phone"
                    value={form.phone}
                    onChangeText={(value) => handleChange('phone', value)}
                    mode="outlined"
                    style={styles.input}
                    keyboardType="phone-pad"
                  />
                </View>
                <View style={styles.inputGroup}>
                  <IconButton icon="account-cog" size={20} color="#244a85" />
                  <TextInput
                    label="Department"
                    value={form.department}
                    onChangeText={(value) => handleChange('department', value)}
                    mode="outlined"
                    style={styles.input}
                  />
                </View>
                <View style={styles.inputGroup}>
                  <IconButton icon="briefcase" size={20} color="#244a85" />
                  <TextInput
                    label="Position"
                    value={form.position}
                    onChangeText={(value) => handleChange('position', value)}
                    mode="outlined"
                    style={styles.input}
                  />
                </View>
                <View style={styles.inputGroup}>
                  <IconButton icon="calendar" size={20} color="#244a85" />
                  <TextInput
                    label="Joining Date"
                    value={form.joinDate}
                    mode="outlined"
                    style={styles.input}
                    onFocus={() => setShowDatePicker(true)}
                  />
                </View>
                {showDatePicker && (
                  <DateTimePicker
                    value={selectedDate || new Date()}
                    mode="date"
                    display="default"
                    onChange={onChangeDate}
                    maximumDate={new Date()}
                  />
                )}
                <View style={styles.inputGroup}>
                  <IconButton icon="cash" size={20} color="#244a85" />
                  <TextInput
                    label="Salary"
                    value={form.salary}
                    onChangeText={(value) => handleChange('salary', value)}
                    mode="outlined"
                    style={styles.input}
                    keyboardType="numeric"
                  />
                </View>

                <Button
                  mode="contained"
                  onPress={handleSubmit}
                  icon="plus"
                  style={styles.button}
                  labelStyle={styles.buttonLabel}
                >
                  Add Employee
                </Button>
              </Card.Content>
            </Card>
          </ScrollView>
        </TouchableWithoutFeedback>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  wrapper: {
    flex: 1,
    backgroundColor: '#f0f4f8',
  },
  container: {
    flexGrow: 1,
    padding: 20,
    justifyContent: 'center',
  },
  card: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 10,
  },
  cardTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#244a85',
    textAlign: 'center',
  },
  inputGroup: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 6,
  },
  input: {
    flex: 1,
    backgroundColor: '#fff',
  },
  button: {
    marginTop: 20,
    backgroundColor: '#244a85',
    borderRadius: 10,
    paddingVertical: 8,
  },
  buttonLabel: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 16,
  },
});

export default AddEmployee;
