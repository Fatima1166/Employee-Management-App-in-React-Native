import React, { useState, useContext, useEffect } from 'react';
import { View, StyleSheet, ScrollView, Alert } from 'react-native';
import { RadioButton, Button, Card, Title, Text, useTheme } from 'react-native-paper';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import { EmployeeContext } from '../context/EmployeeContext';

// Define attendance status options with labels, values, icons, and colors
const attendanceOptions = [
  { label: 'Present', value: 'present', icon: 'check-circle-outline', color: '#0D47A1' },
  { label: 'Absent', value: 'absent', icon: 'close-circle-outline', color: '#B71C1C' },
  { label: 'Halfday', value: 'halfday', icon: 'timelapse', color: '#FF6F00' },
  { label: 'Holiday', value: 'holiday', icon: 'beach', color: '#0277BD' },
];

const AttendanceScreen = () => {
  const { employees, markAttendance } = useContext(EmployeeContext); 
  const [attendanceData, setAttendanceData] = useState({}); 
  const theme = useTheme();

  // Initialize attendanceData with empty values for all employees when component mounts
  useEffect(() => {
    const initial = {};
    employees.forEach(emp => {
      initial[emp.id] = '';
    });
    setAttendanceData(initial);
  }, [employees]);

  // Handle selection of attendance status per employee
  const handleSelect = (id, value) => {
    setAttendanceData(prev => ({ ...prev, [id]: value }));
  };

  // Submit all marked attendance values to context and show confirmation
  const handleSubmit = () => {
    Object.entries(attendanceData).forEach(([id, status]) => {
      if (status) markAttendance(id, status);
    });
    Alert.alert('Success', 'Attendance submitted successfully!');
  };

  // Format today's date for display at the top of the screen
  const today = new Date();
  const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
  const formattedDate = today.toLocaleDateString(undefined, options);

  return (
    <View style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContent}>
        {/* Display today's date */}
        <Text style={styles.dateText}>{formattedDate}</Text>

        {/* Screen heading */}
        <Title style={styles.title}>Mark Attendance</Title>

        {/* Loop through each employee and render a card with radio options */}
        {employees.map((item) => {
          const selected = attendanceData[item.id];
          const selectedOption = attendanceOptions.find(opt => opt.value === selected);

          return (
            <Card key={item.id} style={styles.card}>
              <Card.Content>
                {/* Employee name and department header row */}
                <View style={styles.headerRow}>
                  <View>
                    <Text style={styles.name}>{item.name}</Text>
                    <Text style={styles.info}>
                      <MaterialCommunityIcons name="briefcase-outline" size={16} /> {item.department} - {item.position}
                    </Text>
                  </View>
                  {/* Show selected attendance icon */}
                  {selectedOption && (
                    <MaterialCommunityIcons
                      name={selectedOption.icon}
                      size={30}
                      color={selectedOption.color}
                    />
                  )}
                </View>

                {/* Radio button group for selecting attendance */}
                <RadioButton.Group
                  onValueChange={(value) => handleSelect(item.id, value)}
                  value={attendanceData[item.id] || ''}
                >
                  <View style={styles.radioRow}>
                    {attendanceOptions.map((opt) => (
                      <View key={opt.value} style={styles.radioItem}>
                        <MaterialCommunityIcons name={opt.icon} size={20} color={opt.color} />
                        <RadioButton.Item
                          label={opt.label}
                          value={opt.value}
                          color={opt.color}
                          position="leading"
                          labelStyle={styles.radioLabel}
                          style={{ paddingVertical: 0 }}
                        />
                      </View>
                    ))}
                  </View>
                </RadioButton.Group>
              </Card.Content>
            </Card>
          );
        })}

        {/* Submit button for attendance */}
        <Button
          mode="contained"
          onPress={handleSubmit}
          style={styles.button}
          icon="check"
        >
          Submit Attendance
        </Button>
      </ScrollView>
    </View>
  );
};

// Style definitions for the UI
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f4f6f8',
  },
  scrollContent: {
    padding: 16,
    paddingBottom: 40,
  },
  dateText: {
    fontSize: 16,
    color: '#455a64',
    textAlign: 'center',
    marginBottom: 8,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0D47A1',
    marginBottom: 16,
    textAlign: 'center',
  },
  card: {
    backgroundColor: '#fff',
    borderRadius: 12,
    marginBottom: 16,
    elevation: 4,
  },
  headerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  name: {
    fontSize: 18,
    fontWeight: '600',
    color: '#263238',
  },
  info: {
    fontSize: 14,
    color: '#607d8b',
    marginTop: 2,
  },
  radioRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  radioItem: {
    width: '48%',
    marginBottom: 8,
    flexDirection: 'row',
    alignItems: 'center',
  },
  radioLabel: {
    fontSize: 14,
    color: '#37474f',
    marginLeft: 4,
  },
  button: {
    marginTop: 20,
    borderRadius: 8,
    paddingVertical: 8,
    backgroundColor: '#0D47A1',
  },
});

export default AttendanceScreen;
