import React from 'react';
import {
  View,
  Text,
  Image,
  StyleSheet,
  ScrollView,
  Linking,
  TouchableOpacity,
  Dimensions,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';

// Get screen width for responsive image
const { width: SCREEN_WIDTH } = Dimensions.get('window');

// Main functional component for the Company Introduction screen
const CompanyIntroScreen = () => {
  return (
    // Background gradient covering the whole screen
    <LinearGradient colors={['#e0eafc', '#cfdef3']} style={styles.gradient}>
      {/* ScrollView for scrolling content on smaller screens */}
      <ScrollView contentContainerStyle={styles.container}>
        
        {/* Banner image displayed at the top */}
        <Image
          source={require('../assets/company_banner.png')} // Replace with a wide banner image
          style={styles.bannerImage}
          resizeMode="cover"
        />

        {/* Card-like container for company details */}
        <View style={styles.card}>
          {/* Company Name */}
          <Text style={styles.title}>TechNova Solutions</Text>

          {/* Company Slogan */}
          <Text style={styles.subtitle}>Innovate. Empower. Transform.</Text>

          {/* Brief company introduction */}
          <Text style={styles.description}>
            At <Text style={{ fontWeight: 'bold' }}>TechNova Solutions</Text>, we are pioneers in cutting-edge technologies including{' '}
            <Text style={{ fontWeight: '600' }}>Artificial Intelligence, Cloud Computing</Text>, and{' '}
            <Text style={{ fontWeight: '600' }}>Mobile App Development</Text>.
          </Text>

          {/* Company mission statement */}
          <Text style={styles.description}>
            Our mission is to help businesses thrive in the digital age by delivering smart, scalable, and impactful software
            solutions. With a passionate team of experts, we drive innovation and transformation across industries.
          </Text>

          {/* Contact section with email and phone */}
          <View style={styles.contactContainer}>
            <Text style={styles.contactTitle}>Contact Us</Text>

            {/* Opens email client when pressed */}
            <TouchableOpacity onPress={() => Linking.openURL('mailto:contact@technovasolutions.com')}>
              <Text style={styles.contactText}>📧 contact@technovasolutions.com</Text>
            </TouchableOpacity>

            {/* Opens dialer when pressed */}
            <TouchableOpacity onPress={() => Linking.openURL('tel:+1234567890')}>
              <Text style={styles.contactText}>📞 +1 (234) 567-890</Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </LinearGradient>
  );
};

export default CompanyIntroScreen;

// Styles for the screen components
const styles = StyleSheet.create({
  gradient: {
    flex: 1,
  },
  container: {
    paddingBottom: 40,
    alignItems: 'center',
  },
  bannerImage: {
    width: SCREEN_WIDTH,
    height: 220,
    borderBottomLeftRadius: 30,
    borderBottomRightRadius: 30,
    marginBottom: 20,
  },
  card: {
    backgroundColor: '#ffffff',
    borderRadius: 20,
    padding: 25,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 5 },
    shadowOpacity: 0.1,
    shadowRadius: 15,
    elevation: 8,
    width: '90%',
    alignItems: 'center',
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#2c3e50',
    marginBottom: 5,
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 16,
    color: '#7f8c8d',
    marginBottom: 15,
    fontStyle: 'italic',
  },
  description: {
    fontSize: 16,
    color: '#34495e',
    textAlign: 'center',
    marginBottom: 12,
    lineHeight: 24,
  },
  contactContainer: {
    marginTop: 20,
    borderTopWidth: 1,
    borderTopColor: '#ddd',
    paddingTop: 15,
    width: '100%',
    alignItems: 'center',
  },
  contactTitle: {
    fontSize: 20,
    fontWeight: '600',
    color: '#2c3e50',
    marginBottom: 10,
  },
  contactText: {
    fontSize: 16,
    color: '#2980b9',
    marginBottom: 8,
  },
});
