import React from 'react';
import { View, StyleSheet, ScrollView } from 'react-native';
import { Button, Text, Card } from 'react-native-paper';

// DashboardScreen: The main landing screen after login/registration
const DashboardScreen = ({ navigation }) => {
  return (
    // Allows vertical scrolling if content overflows the screen
    <ScrollView contentContainerStyle={styles.scrollContainer}>
      <View style={styles.container}>
        {/* App title heading */}
        <Text variant="headlineMedium" style={styles.title}>
          Employee Management Portal
        </Text>

        {/* Card holds all navigation buttons */}
        <Card style={styles.card}>
          <Card.Content>
            {/* Navigate to Employee List screen */}
            <Button
              mode="contained"
              onPress={() => navigation.navigate('EmployeeList')}
              style={styles.button}
              contentStyle={styles.buttonContent}
              labelStyle={styles.buttonLabel}
              icon="account-group"
            >
              View Employee List
            </Button>

            {/* Navigate to Add Employee screen */}
            <Button
              mode="contained"
              onPress={() => navigation.navigate('AddEmployee')}
              style={styles.button}
              contentStyle={styles.buttonContent}
              labelStyle={styles.buttonLabel}
              icon="account-plus"
            >
              Add New Employee
            </Button>
            {/* Navigate to Task Screen */}
            <Button
              mode="contained"
              onPress={() => navigation.navigate('TaskScreen')}
              style={styles.button}
              contentStyle={styles.buttonContent}
              labelStyle={styles.buttonLabel}
              icon="clipboard-text"
            >
              Add Tasks
            </Button>

            {/* Navigate to Attendance Screen */}
            <Button
              mode="contained"
              onPress={() => navigation.navigate('AttendanceScreen')}
              style={styles.button}
              contentStyle={styles.buttonContent}
              labelStyle={styles.buttonLabel}
              icon="calendar-check"
            >
              Employee Attendance
            </Button>

            {/* Navigate to Payment/Salary Screen */}
            <Button
              mode="contained"
              onPress={() => navigation.navigate('PaymentScreen')}
              style={styles.button}
              contentStyle={styles.buttonContent}
              labelStyle={styles.buttonLabel}
              icon="chart-bar"
            >
              Update payment
            </Button>
          </Card.Content>
        </Card>
      </View>
    </ScrollView>
  );
};

// Styling for the dashboard screen
const styles = StyleSheet.create({
  scrollContainer: {
    flexGrow: 1,
    justifyContent: 'center',
    backgroundColor: '#f2f4f8', // Light background
    padding: 16,
  },
  container: {
    flex: 1,
    justifyContent: 'center',
  },
  title: {
    color: '#1E3A8A', // Navy blue
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 24,
  },
  card: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 20,
    elevation: 4,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 2 },
  },
  button: {
    marginVertical: 10,
    borderRadius: 12,
    backgroundColor: '#1E3A8A', // Consistent theme
  },
  buttonContent: {
    paddingVertical: 12,
  },
  buttonLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: '#ffffff',
  },
});

export default DashboardScreen;
