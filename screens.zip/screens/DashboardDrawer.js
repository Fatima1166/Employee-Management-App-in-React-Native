// screens/DashboardDrawer.js

import React from 'react';
import { createDrawerNavigator } from '@react-navigation/drawer';

import Dashboard from './Dashboard';
import CompanyIntroScreen from './CompanyIntroScreen';
import AboutUsScreen from './AboutUsScreen';

const Drawer = createDrawerNavigator();

export default function DashboardDrawer() {
  return (
    <Drawer.Navigator initialRouteName="DashboardMain">
      <Drawer.Screen
        name="DashboardMain"
        component={Dashboard}
        options={{ title: 'Dashboard' }}
      />
      <Drawer.Screen
        name="CompanyIntro"
        component={CompanyIntroScreen}
        options={{ title: 'Company Intro' }}
      />
      <Drawer.Screen
        name="AboutUs"
        component={AboutUsScreen}
        options={{ title: 'About Us' }}
      />
    </Drawer.Navigator>
  );
}
