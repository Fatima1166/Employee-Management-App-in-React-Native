import React, { useContext, useState } from 'react';
import { View, StyleSheet, ScrollView } from 'react-native';
import { Button, TextInput, IconButton, Text } from 'react-native-paper';
import { EmployeeContext } from '../context/EmployeeContext';

const EditEmployee = ({ route, navigation }) => {
  const { employee } = route.params;
  const { updateEmployee } = useContext(EmployeeContext);
  const [form, setForm] = useState({ ...employee });

  const handleChange = (key, value) => setForm({ ...form, [key]: value });

  const handleSubmit = () => {
    updateEmployee(form);
    navigation.goBack();
  };

  return (
    <View style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollView}>
        <View style={styles.headingContainer}>
          <IconButton 
            icon="account-edit" // Icon for the heading
            size={30} 
            color="#fff"
          />
          <Text style={styles.heading}>Edit Employee Details</Text>
        </View>

        {['name', 'email', 'phone', 'department', 'position', 'joinDate'].map(field => (
          <TextInput
            key={field}
            label={field.charAt(0).toUpperCase() + field.slice(1)}
            value={form[field]}
            onChangeText={(value) => handleChange(field, value)}
            style={styles.input}
            theme={{ colors: { primary: '#244a85', underlineColor: 'transparent' } }}
            left={<TextInput.Affix text={<IconButton icon={getIconForField(field)} color="#244a85" />} />}
          />
        ))}

        <Button
          mode="contained"
          onPress={handleSubmit}
          style={styles.button}
          icon="check-circle-outline"  // Icon added to the button
          labelStyle={styles.buttonText} // Customizing the button text
        >
          Update
        </Button>
      </ScrollView>
    </View>
  );
};

const getIconForField = (field) => {
  switch (field) {
    case 'name':
      return 'account';
    case 'email':
      return 'email';
    case 'phone':
      return 'phone';
    case 'department':
      return 'office-building';
    case 'position':
      return 'badge-account';
    case 'joinDate':
      return 'calendar';
    default:
      return 'help-circle';
  }
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#1A3E72', // Dark blue background
    padding: 20,
  },
  scrollView: { paddingBottom: 20 }, // To ensure there's enough space at the bottom
  input: {
    marginBottom: 15,
    backgroundColor: 'white',
    borderRadius: 8,
    paddingHorizontal: 10,
  },
  button: {
    marginTop: 20,
    backgroundColor: '#5C8DFF', // Light blue button color
    borderRadius: 8,
    flexDirection: 'row',
    justifyContent: 'center', // Centering the button content
  },
  buttonText: {
    fontWeight: 'bold', // Making button text bold
  },
  headingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  heading: {
    fontSize: 24,
    fontWeight: 'bold',
    color: 'white', // Bold heading with white color
    marginLeft: 10, // Space between the icon and the title
  },
});

export default EditEmployee;
