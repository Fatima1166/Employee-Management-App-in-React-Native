import React, { useContext } from 'react';
import { ScrollView, View, StyleSheet } from 'react-native';
import { Text, Card, Button, Divider } from 'react-native-paper';
import { EmployeeContext } from '../context/EmployeeContext';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';

const EmployeeDetail = ({ route, navigation }) => {
  // Get employee passed from navigation route
  const { employee: passedEmployee } = route.params;

  // Access employee data from context
  const { employees } = useContext(EmployeeContext);

  // Find the latest version of the selected employee from context
  const employee = employees.find((emp) => emp.id === passedEmployee.id);

  // Show error if employee not found
  if (!employee) {
    return (
      <View style={styles.container}>
        <Text style={styles.errorText}>Employee not found.</Text>
      </View>
    );
  }

  // Calculate total attendance and payment summary
  const totalAttendance =
    employee.attendance.present +
    employee.attendance.absent +
    employee.attendance.halfday +
    employee.attendance.holiday;

  const bonus = parseInt(employee.bonus || 0);
  const advance = parseInt(employee.advance || 0);
  const salary = parseInt(employee.salary || 0);
  const totalPayable = salary + bonus - advance;

  // UI: Main content rendering
  return (
    <ScrollView contentContainerStyle={styles.scrollContainer}>
      <Card style={styles.card}>
        {/* Header with employee name and position */}
        <Card.Title
          title={employee.name}
          subtitle={employee.position}
          left={() => (
            <MaterialCommunityIcons
              name="account-circle"
              size={50}
              color="#3e4a89"
              style={{ marginRight: 10 }}
            />
          )}
          titleStyle={styles.cardTitle}
          subtitleStyle={styles.cardSubtitle}
        />
        <Card.Content>
          <Divider style={styles.divider} />

          {/* Personal Information Section */}
          <Text style={styles.sectionTitle}>👤 Personal Info</Text>
          <View style={styles.infoBlock}>
            <InfoRow icon="email" label="Email" value={employee.email} />
            <InfoRow icon="phone" label="Phone" value={employee.phone} />
            <InfoRow icon="domain" label="Department" value={employee.department} />
            <InfoRow icon="calendar-month" label="Join Date" value={employee.joinDate} />
          </View>

          {/* Attendance Summary Section */}
          <Text style={styles.sectionTitle}>📅 Attendance Summary</Text>
          <View style={styles.infoBlock}>
            <SummaryRow label="✅ Present" value={employee.attendance.present} color="#4caf50" />
            <SummaryRow label="❌ Absent" value={employee.attendance.absent} color="#f44336" />
            <SummaryRow label="🕘 Halfday" value={employee.attendance.halfday} color="#ff9800" />
            <SummaryRow label="🏖 Holiday" value={employee.attendance.holiday} color="#2196f3" />
            <SummaryRow label="📊 Total" value={totalAttendance} bold />
          </View>

          {/* Payment Summary Section */}
          <Text style={styles.sectionTitle}>💸 Payment Summary</Text>
          <View style={styles.infoBlock}>
            <SummaryRow label="💼 Salary" value={`Rs. ${salary}`} />
            <SummaryRow label="🎁 Bonus" value={`Rs. ${bonus}`} />
            <SummaryRow label="💳 Advance" value={`Rs. ${advance}`} />
            <SummaryRow label="💰 Total Payable" value={`Rs. ${totalPayable}`} bold />
          </View>

          {/* Back button to navigate to employee list */}
          <Button
            mode="contained"
            icon="arrow-left"
            onPress={() => navigation.goBack()}
            style={styles.button}
            labelStyle={styles.buttonLabel}
          >
            Back to List
          </Button>
        </Card.Content>
      </Card>
    </ScrollView>
  );
};

// Reusable row for personal info with icon
const InfoRow = ({ icon, label, value }) => (
  <View style={styles.infoRow}>
    <MaterialCommunityIcons name={icon} size={22} color="#3e4a89" />
    <Text style={styles.infoText}>
      {label}: <Text style={{ fontWeight: '600' }}>{value}</Text>
    </Text>
  </View>
);

// Reusable row for attendance and payment summary
const SummaryRow = ({ label, value, color = '#333', bold = false }) => (
  <View style={styles.summaryRow}>
    <Text style={[styles.summaryLabel, { color }, bold && { fontWeight: 'bold' }]}>
      {label}:
    </Text>
    <Text style={[styles.summaryValue, bold && { fontWeight: 'bold', color: '#3e4a89' }]}>
      {value}
    </Text>
  </View>
);

// Styles for layout and design
const styles = StyleSheet.create({
  scrollContainer: {
    flexGrow: 1,
    padding: 15,
    backgroundColor: '#f0f4fb', // Soft blue-gray
  },
  card: {
    backgroundColor: '#ffffff',
    borderRadius: 20,
    paddingVertical: 20,
    paddingHorizontal: 10,
    elevation: 5,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 6,
    shadowOffset: { width: 0, height: 4 },
  },
  cardTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#3e4a89',
  },
  cardSubtitle: {
    fontSize: 16,
    color: '#607d8b',
  },
  divider: {
    marginVertical: 10,
  },
  sectionTitle: {
    marginTop: 15,
    fontSize: 18,
    fontWeight: 'bold',
    color: '#3e4a89',
    marginBottom: 8,
  },
  infoBlock: {
    backgroundColor: '#f8fbff',
    borderRadius: 10,
    padding: 12,
    marginBottom: 15,
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 6,
  },
  infoText: {
    fontSize: 16,
    marginLeft: 8,
    color: '#444',
  },
  summaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginVertical: 4,
  },
  summaryLabel: {
    fontSize: 16,
  },
  summaryValue: {
    fontSize: 16,
  },
  button: {
    marginTop: 15,
    backgroundColor: '#3e4a89',
    borderRadius: 10,
  },
  buttonLabel: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  errorText: {
    fontSize: 18,
    color: 'red',
    textAlign: 'center',
    marginTop: 40,
  },
});

export default EmployeeDetail;



