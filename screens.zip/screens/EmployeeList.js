import React, { useContext } from 'react';
import { View, FlatList, StyleSheet } from 'react-native';
import { Button, Card, Text, Avatar, Appbar } from 'react-native-paper';
import { SafeAreaView } from 'react-native-safe-area-context';
import { EmployeeContext } from '../context/EmployeeContext';

const EmployeeList = ({ navigation }) => {
  // Access employee data and delete function from context
  const { employees, deleteEmployee } = useContext(EmployeeContext);

  // Renders each employee card
  const renderItem = ({ item }) => (
    <Card style={styles.card} elevation={4}>
      <Card.Title
        title={item.name}
        subtitle={item.position}
        left={(props) => (
          <Avatar.Icon {...props} icon="account" style={styles.avatar} color="#fff" />
        )}
        titleStyle={styles.cardTitle}
        subtitleStyle={styles.cardSubtitle}
      />
      <Card.Content>
        <Text style={styles.cardText}>📧 Email: {item.email}</Text>
        <Text style={styles.cardText}>📱 Phone: {item.phone}</Text>
      </Card.Content>
      <Card.Actions style={styles.cardActions}>
        {/* View employee details */}
        <Button
          onPress={() => navigation.navigate('EmployeeDetail', { employee: item })}
          icon="eye"
          mode="text"
          labelStyle={styles.buttonLabel}
        >
          View
        </Button>

        {/* Edit employee */}
        <Button
          onPress={() => navigation.navigate('EditEmployee', { employee: item })}
          icon="pencil"
          mode="text"
          labelStyle={styles.buttonLabel}
        >
          Edit
        </Button>

        {/* Delete employee */}
        <Button
          onPress={() => deleteEmployee(item.id)}
          icon="delete"
          mode="text"
          labelStyle={[styles.buttonLabel, { color: 'red' }]}
        >
          Delete
        </Button>
      </Card.Actions>
    </Card>
  );

  return (
    <SafeAreaView style={styles.safeArea}>
      {/* Header */}
      <Appbar.Header style={styles.appbarHeader}>
        <Appbar.Content
          title="Employee List"
          titleStyle={styles.appbarTitle}
        />
      </Appbar.Header>

      {/* FlatList for displaying all employees */}
      <FlatList
        data={employees}
        keyExtractor={(item) => item.id}
        renderItem={renderItem}
        contentContainerStyle={styles.listContent}
        
        // Displayed when no employees are present
        ListEmptyComponent={
          <Text style={styles.emptyText}>No employees found. Add some! 🧑‍💼</Text>
        }

        // Footer with navigation button to Dashboard
        ListFooterComponent={
          <View style={styles.midButtonContainer}>
            <Button
              mode="contained"
              icon="view-dashboard"
              onPress={() => navigation.navigate('Dashboard')}
              style={styles.dashboardButton}
              contentStyle={styles.dashboardButtonContent}
              labelStyle={styles.dashboardButtonLabel}
            >
              Go to Dashboard
            </Button>
          </View>
        }
      />
    </SafeAreaView>
  );
};

// Styles for the screen
const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#D6EAF8', // light blue background
  },
  appbarHeader: {
    backgroundColor: '#D6EAF8', // matches background for seamless look
    elevation: 0, // removes shadow
  },
  appbarTitle: {
    color: '#1E3A8A', // navy blue for contrast
    fontWeight: 'bold',
    fontSize: 25,
  },
  listContent: {
    padding: 16,
    paddingBottom: 80,
  },
  card: {
    marginBottom: 16,
    borderRadius: 16,
    backgroundColor: '#ffffff',
  },
  avatar: {
    backgroundColor: '#1E3A8A',
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#1E3A8A',
  },
  cardSubtitle: {
    fontSize: 14,
    color: '#555',
  },
  cardText: {
    fontSize: 14,
    color: '#333',
    marginVertical: 2,
  },
  cardActions: {
    justifyContent: 'space-around',
    paddingHorizontal: 8,
    paddingBottom: 8,
  },
  buttonLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: '#1E3A8A',
  },
  emptyText: {
    textAlign: 'center',
    marginTop: 100,
    fontSize: 16,
    color: '#666',
  },
  midButtonContainer: {
    marginTop: 20,
    alignItems: 'center',
    marginBottom: 20,
  },
  dashboardButton: {
    backgroundColor: '#1E3A8A',
    borderRadius: 12,
    width: 220,
  },
  dashboardButtonContent: {
    paddingVertical: 10,
  },
  dashboardButtonLabel: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#fff',
  },
});

export default EmployeeList;
