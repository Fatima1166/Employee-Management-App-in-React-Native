import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
  Image,
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  ScrollView
} from 'react-native';
import { Picker } from '@react-native-picker/picker';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';

// Login screen component
export default function LoginScreen({ navigation }) {
  // State variables for form inputs
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('staff');
  const [loading, setLoading] = useState(false);

  // Function to validate email format //regular expression
  const validateEmail = (email) => {
    const regex = /^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/;
    return regex.test(email);
  };

  // Function to handle login logic
  const handleLogin = () => {
    if (!email || !password) {
      Alert.alert('Error', 'Please enter both email and password.');
      return;
    }

    if (!validateEmail(email)) {
      Alert.alert('Invalid Email', 'Please enter a valid email address.');
      return;
    }

    // Simulate loading and successful login
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      Alert.alert('Success', `Logged in as ${role.toUpperCase()} (${email})`);
      navigation.replace('Dashboard'); // Navigate to dashboard
    }, 1500);
  };

  return (
    // View adjusts for keyboard on iOS
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : null}
      style={{ flex: 1 }}
    >
      {/* Scrollable content */}
      <ScrollView contentContainerStyle={styles.container} keyboardShouldPersistTaps="handled">
        {/* App logo */}
        <Image source={require('../assets/login.png')} style={styles.logo} />
        <Text style={styles.title}>Employee Management Login</Text>

        {/* Email input */}
        <View style={styles.inputContainer}>
          <MaterialIcons name="email" size={20} color="#B0B0B0" style={styles.icon} />
          <TextInput
            style={styles.input}
            placeholder="Email"
            placeholderTextColor="#B0B0B0"
            keyboardType="email-address"
            autoCapitalize="none"
            value={email}
            onChangeText={setEmail}
            editable={!loading}
          />
        </View>

        {/* Password input */}
        <View style={styles.inputContainer}>
          <MaterialIcons name="lock" size={20} color="#B0B0B0" style={styles.icon} />
          <TextInput
            style={styles.input}
            placeholder="Password"
            placeholderTextColor="#B0B0B0"
            secureTextEntry
            value={password}
            onChangeText={setPassword}
            editable={!loading}
          />
        </View>

        {/* Role picker */}
        <Text style={styles.label}>Select Role:</Text>
        <View style={styles.pickerContainer}>
          <Picker
            selectedValue={role}
            onValueChange={(itemValue) => setRole(itemValue)}
            style={styles.picker}
            mode="dropdown"
            dropdownIconColor="#FFFFFF"
            enabled={!loading}
          >
            <Picker.Item label="Staff" value="staff" />
            <Picker.Item label="HR / Admin" value="admin" />
          </Picker>
        </View>

        {/* Submit button */}
        <TouchableOpacity
          style={[styles.loginButton, loading && styles.disabledButton]}
          onPress={handleLogin}
          disabled={loading}
          activeOpacity={0.8}
        >
          {loading ? (
            <ActivityIndicator color="#FFF" />
          ) : (
            <Text style={styles.loginButtonText}>Submit</Text>
          )}
        </TouchableOpacity>

        {/* Link to registration screen */}
        <TouchableOpacity
          onPress={() => navigation.navigate('Register')}
          disabled={loading}
        >
          <Text style={styles.registerText}>Don't have an account? Register</Text>
        </TouchableOpacity>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

// Styles for the login screen
const styles = StyleSheet.create({
  container: {
    backgroundColor: '#0A2540',
    justifyContent: 'center',
    paddingHorizontal: 20,
    paddingTop: 60,
    paddingBottom: 40,
    flexGrow: 1,
  },
  logo: {
    width: 120,
    height: 120,
    alignSelf: 'center',
    marginBottom: 20,
    resizeMode: 'contain',
  },
  title: {
    color: '#FFFFFF',
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 30,
    alignSelf: 'center',
    textAlign: 'center',
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#144272',
    borderRadius: 8,
    marginBottom: 20,
    paddingHorizontal: 10,
  },
  icon: {
    marginRight: 8,
  },
  input: {
    flex: 1,
    color: '#FFFFFF',
    paddingVertical: 12,
    fontSize: 16,
  },
  label: {
    color: '#B0B0B0',
    marginBottom: 5,
    fontSize: 16,
  },
  pickerContainer: {
    backgroundColor: '#144272',
    borderRadius: 8,
    marginBottom: 30,
    height: 50,
    justifyContent: 'center',
  },
  picker: {
    color: '#FFFFFF',
    flex: 1,
  },
  loginButton: {
    backgroundColor: '#1E5AB9',
    paddingVertical: 12,
    borderRadius: 25,
    alignItems: 'center',
    marginBottom: 20,
  },
  disabledButton: {
    backgroundColor: '#3B72D9',
  },
  loginButtonText: {
    color: '#FFFFFF',
    fontSize: 15,
    fontWeight: '600',
  },
  registerText: {
    color: '#B0B0B0',
    fontSize: 16,
    textAlign: 'center',
    textDecorationLine: 'underline',
  },
});
