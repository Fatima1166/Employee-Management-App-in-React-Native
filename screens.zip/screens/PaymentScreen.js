
import React, { useContext, useState, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList, TextInput, Button, Alert } from 'react-native';
import { EmployeeContext } from '../context/EmployeeContext'; // import the right context
import Icon from 'react-native-vector-icons/Ionicons'; // ✅ Fixed import

const PaymentScreen = () => {
  const { employees, updateEmployee } = useContext(EmployeeContext);

  // Local state to edit payment info for each employee
  const [paymentData, setPaymentData] = useState({});

  // Initialize local paymentData state from employees context data
  useEffect(() => {
    const initialData = {};
    employees.forEach(emp => {
      initialData[emp.id] = {
        salary: emp.salary || '',
        bonus: emp.bonus || '',
        advance: emp.advance || '',
      };
    });
    setPaymentData(initialData);
  }, [employees]);

  // Update local state on input change
  const handleChange = (id, field, value) => {
    setPaymentData(prev => ({
      ...prev,
      [id]: {
        ...prev[id],
        [field]: value,
      },
    }));
  };

  // Save changes to EmployeeContext and clear inputs
  const handleSave = (id) => {
    const data = paymentData[id];
    if (!data) {
      Alert.alert('Error', 'No payment data to save.');
      return;
    }
    // Validate numbers or convert empty strings to '0'
    const updatedEmployee = {
      id,
      salary: data.salary.trim() === '' ? '0' : data.salary,
      bonus: data.bonus.trim() === '' ? '0' : data.bonus,
      advance: data.advance.trim() === '' ? '0' : data.advance,
    };
    updateEmployee(updatedEmployee);
    Alert.alert('Success', 'Payment data saved.');

    // Clear input fields after save (optional)
    setPaymentData(prev => ({
      ...prev,
      [id]: { salary: '', bonus: '', advance: '' },
    }));
  };

  // Reset bonus and advance locally AND update context to persist reset
  const handleReset = (id) => {
    setPaymentData(prev => ({
      ...prev,
      [id]: {
        ...prev[id],
        bonus: '',
        advance: '',
      }
    }));

    updateEmployee({
      id,
      bonus: '0',
      advance: '0',
    });
  };

  const renderItem = ({ item }) => {
    const current = paymentData[item.id] || { salary: '', bonus: '', advance: '' };
    // Calculate total salary = salary + bonus - advance
    const totalSalary =
      Number(current.salary || item.salary || 0) +
      Number(current.bonus || item.bonus || 0) -
      Number(current.advance || item.advance || 0);

    return (
      <View style={styles.card}>
        <View style={styles.nameRow}>
          <Icon name="person-circle-outline" size={30} color="#0B3D91" />
          <View style={{ marginLeft: 8 }}>
            <Text style={styles.name}>{item.name}</Text>
            <Text style={styles.department}>{item.department}</Text>
          </View>
        </View>

        <View style={styles.inputGroup}>
          <Text style={styles.label}>Salary</Text>
          <TextInput
            style={styles.input}
            placeholder="Salary"
            keyboardType="numeric"
            value={current.salary}
            onChangeText={(value) => handleChange(item.id, 'salary', value)}
          />
        </View>

        <View style={styles.inputGroup}>
          <Text style={styles.label}>Bonus</Text>
          <TextInput
            style={styles.input}
            placeholder="Bonus"
            keyboardType="numeric"
            value={current.bonus}
            onChangeText={(value) => handleChange(item.id, 'bonus', value)}
          />
        </View>

        <View style={styles.inputGroup}>
          <Text style={styles.label}>Advance</Text>
          <TextInput
            style={styles.input}
            placeholder="Advance"
            keyboardType="numeric"
            value={current.advance}
            onChangeText={(value) => handleChange(item.id, 'advance', value)}
          />
        </View>

        <Text style={styles.totalSalary}>
          Total Salary: {totalSalary.toFixed(2)}
        </Text>

        <View style={styles.buttonRow}>
          <View style={styles.buttonContainer}>
            <Button
              title="Save"
              color="#0B3D91"
              onPress={() => handleSave(item.id)}
            />
          </View>
          <View style={styles.buttonContainer}>
            <Button
              title="Reset"
              color="#d9534f"
              onPress={() => handleReset(item.id)}
            />
          </View>
        </View>
      </View>
    );
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Update Payment Details</Text>
      <FlatList
        data={employees}
        keyExtractor={item => item.id}
        renderItem={renderItem}
        contentContainerStyle={{ paddingBottom: 20 }}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff', padding: 20 },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    color: '#0B3D91',
    textAlign: 'center',
  },
  card: {
    backgroundColor: '#E6F0FA',
    borderRadius: 8,
    padding: 15,
    marginBottom: 15,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 3,
  },
  nameRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  name: {
    fontSize: 20,
    fontWeight: '600',
    color: '#0B3D91',
  },
  department: {
    fontSize: 14,
    fontWeight: '500',
    color: '#244a85',
    marginTop: 2,
  },
  inputGroup: {
    marginBottom: 12,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 4,
    color: '#0B3D91',
  },
  input: {
    height: 40,
    backgroundColor: '#fff',
    borderRadius: 6,
    borderColor: '#0B3D91',
    borderWidth: 1,
    paddingHorizontal: 10,
  },
  buttonRow: {
    flexDirection: 'row',
    justifyContent: 'flex-start',
    marginTop: 10,
  },
  buttonContainer: {
    marginRight: 15,
    width: 100,
  },
  totalSalary: {
    fontSize: 16,
    fontWeight: '700',
    color: '#0B3D91',
    marginTop: 10,
  },
});

export default PaymentScreen;
