import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
  Image,
  ScrollView,
} from 'react-native';
import { Picker } from '@react-native-picker/picker';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';

// Register screen component
export default function RegisterScreen({ navigation }) {
  // Form input states
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [role, setRole] = useState('staff');
  const [loading, setLoading] = useState(false);

  // Registration logic
  const handleRegister = () => {
    if (!fullName || !email || !password || !confirmPassword) {
      Alert.alert('Error', 'Please fill all fields');
      return;
    }
    if (password !== confirmPassword) {
      Alert.alert('Error', 'Passwords do not match');
      return;
    }

    setLoading(true);

    setTimeout(() => {
      setLoading(false);
      Alert.alert('Success', `Registered as ${role.toUpperCase()} (${email})`);
      navigation.replace('Dashboard');
    }, 1500);
  };

  return (
    // Scrollable form layout
    <ScrollView contentContainerStyle={styles.container}>
      {/* Logo */}
      <Image source={require('../assets/register.png')} style={styles.logo} />
      <Text style={styles.title}>Register New Account</Text>

      {/* Full Name input */}
      <View style={styles.inputContainer}>
        <MaterialIcons name="person" size={16} color="#B0B0B0" style={styles.icon} />
        <TextInput
          style={styles.input}
          placeholder="Full Name"
          placeholderTextColor="#B0B0B0"
          value={fullName}
          onChangeText={setFullName}
          editable={!loading}
        />
      </View>

      {/* Email input */}
      <View style={styles.inputContainer}>
        <MaterialIcons name="email" size={16} color="#B0B0B0" style={styles.icon} />
        <TextInput
          style={styles.input}
          placeholder="Email"
          placeholderTextColor="#B0B0B0"
          keyboardType="email-address"
          autoCapitalize="none"
          value={email}
          onChangeText={setEmail}
          editable={!loading}
        />
      </View>

      {/* Password input */}
      <View style={styles.inputContainer}>
        <MaterialIcons name="lock" size={16} color="#B0B0B0" style={styles.icon} />
        <TextInput
          style={styles.input}
          placeholder="Password"
          placeholderTextColor="#B0B0B0"
          secureTextEntry
          value={password}
          onChangeText={setPassword}
          editable={!loading}
        />
      </View>

      {/* Confirm Password input */}
      <View style={styles.inputContainer}>
        <MaterialIcons name="lock" size={16} color="#B0B0B0" style={styles.icon} />
        <TextInput
          style={styles.input}
          placeholder="Confirm Password"
          placeholderTextColor="#B0B0B0"
          secureTextEntry
          value={confirmPassword}
          onChangeText={setConfirmPassword}
          editable={!loading}
        />
      </View>

      {/* Role selector */}
      <View style={styles.pickerContainer}>
        <Picker
          selectedValue={role}
          onValueChange={(itemValue) => setRole(itemValue)}
          style={styles.picker}
          mode="dropdown"
          dropdownIconColor="#FFFFFF"
          enabled={!loading}
        >
          <Picker.Item label="Staff" value="staff" />
          <Picker.Item label="HR / Admin" value="admin" />
        </Picker>
      </View>

      {/* Submit button */}
      <TouchableOpacity
        style={[styles.registerButton, loading && styles.disabledButton]}
        onPress={handleRegister}
        disabled={loading}
        activeOpacity={0.8}
      >
        <Text style={styles.registerButtonText}>Submit</Text>
      </TouchableOpacity>

      {/* Link to Login screen */}
      <TouchableOpacity
        onPress={() => navigation.navigate('Login')}
        disabled={loading}
      >
        <Text style={styles.loginText}>Already have an account? Login</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

// Styles for the Register screen
const styles = StyleSheet.create({
  container: {
    backgroundColor: '#0A2540',
    justifyContent: 'center',
    paddingHorizontal: 20,
    paddingVertical: 30,
    flexGrow: 1,
  },
  logo: {
    width: 100,
    height: 100,
    alignSelf: 'center',
    marginBottom: 20,
    resizeMode: 'contain',
  },
  title: {
    color: '#FFFFFF',
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 25,
    alignSelf: 'center',
    textAlign: 'center',
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#144272',
    borderRadius: 8,
    marginBottom: 12,
    paddingHorizontal: 10,
  },
  icon: {
    marginRight: 8,
  },
  input: {
    flex: 1,
    color: '#FFFFFF',
    paddingVertical: 10,
    fontSize: 14,
  },
  pickerContainer: {
    backgroundColor: '#144272',
    borderRadius: 8,
    marginBottom: 25,
    height: 45,
    justifyContent: 'center',
  },
  picker: {
    color: '#FFFFFF',
    flex: 1,
  },
  registerButton: {
    backgroundColor: '#1E5AB9',
    paddingVertical: 12,
    borderRadius: 25,
    alignItems: 'center',
    marginBottom: 18,
  },
  disabledButton: {
    backgroundColor: '#3B72D9',
  },
  registerButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
  loginText: {
    color: '#B0B0B0',
    fontSize: 14,
    textAlign: 'center',
    textDecorationLine: 'underline',
  },
});
