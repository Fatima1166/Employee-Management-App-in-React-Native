import React, { useState, useContext } from 'react';
import { View, StyleSheet, FlatList, Alert } from 'react-native';
import { Button, Card, Text, TextInput, Checkbox, Divider, IconButton } from 'react-native-paper';
import { EmployeeContext } from '../context/EmployeeContext';
import { TaskContext } from '../context/TaskContext';
import { DatePickerModal } from 'react-native-paper-dates';
import { en, registerTranslation } from 'react-native-paper-dates';

registerTranslation('en', en); // Register English locale for the date picker

const TaskScreen = () => {
  // Accessing employees and tasks from context
  const { employees = [] } = useContext(EmployeeContext);
  const { tasks, addTask, updateTask, deleteTask } = useContext(TaskContext);

  // Local state
  const [selectedEmployees, setSelectedEmployees] = useState([]);
  const [form, setForm] = useState({
    title: '',
    description: '',
    issueDate: '',
    lastDate: '',
  });
  const [editingTaskId, setEditingTaskId] = useState(null);
  const [openIssuePicker, setOpenIssuePicker] = useState(false);
  const [openLastPicker, setOpenLastPicker] = useState(false);

  // Handles input changes in the form
  const handleChange = (key, value) => {
    setForm((prev) => ({ ...prev, [key]: value }));
  };

  // Select or deselect an employee
  const toggleEmployeeSelection = (id) => {
    setSelectedEmployees((prev) =>
      prev.includes(id) ? prev.filter((empId) => empId !== id) : [...prev, id]
    );
  };

  // Add or update a task based on current state
  const handleAddOrUpdateTask = () => {
    const { title, description, issueDate, lastDate } = form;
    if (
      title.trim() &&
      description.trim() &&
      issueDate &&
      lastDate &&
      selectedEmployees.length > 0
    ) {
      const newTask = {
        id: editingTaskId || Date.now().toString(),
        title: title.trim(),
        description: description.trim(),
        issueDate,
        lastDate,
        assignedTo: selectedEmployees,
      };

      editingTaskId ? updateTask(newTask) : addTask(newTask);
      resetForm();
    } else {
      Alert.alert('Validation Error', 'All fields are required, and at least one employee must be selected.');
    }
  };

  // Prepare form for editing an existing task
  const handleEditTask = (task) => {
    setForm({
      title: task.title,
      description: task.description,
      issueDate: task.issueDate,
      lastDate: task.lastDate,
    });
    setSelectedEmployees(task.assignedTo);
    setEditingTaskId(task.id);
  };

  // Delete task with confirmation
  const handleDeleteTask = (id) => {
    Alert.alert('Delete Task', 'Are you sure you want to delete this task?', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Delete', onPress: () => deleteTask(id) },
    ]);
  };

  // Reset form to default state
  const resetForm = () => {
    setForm({ title: '', description: '', issueDate: '', lastDate: '' });
    setSelectedEmployees([]);
    setEditingTaskId(null);
  };

  // Display employee names from IDs
  const getEmployeeNames = (ids) =>
    ids
      .map((id) => {
        const emp = employees.find((e) => e.id === id);
        return emp ? `${emp.name} (${emp.department || 'No Dept'})` : 'Unknown';
      })
      .join(', ');

  // Format date for display
  const formatDate = (date) => {
    return date ? date.toISOString().split('T')[0] : '';
  };

  return (
    <>
      {/* Task Form and Task List */}
      <FlatList
        contentContainerStyle={styles.container}
        data={tasks}
        keyExtractor={(item) => item.id}
        ListHeaderComponent={
          <>
            {/* Form Header */}
            <Text variant="headlineSmall" style={styles.heading}>
              {editingTaskId ? '✏️ Edit Task' : '➕ Add New Task'}
            </Text>

            {/* Task Title Input */}
            <TextInput
              label="📝Task Title"
              value={form.title}
              onChangeText={(text) => handleChange('title', text)}
              mode="outlined"
              style={styles.input}
              left={<TextInput.Icon name="format-title" color="#244a85" />}
            />

            {/* Task Description Input */}
            <TextInput
              label="📄Description"
              value={form.description}
              onChangeText={(text) => handleChange('description', text)}
              multiline
              numberOfLines={3}
              mode="outlined"
              style={styles.input}
              left={<TextInput.Icon name="file-document-outline" color="#244a85" />}
            />

            {/* Issue Date Picker */}
            <TextInput
              label="📅 Issue Date"
              value={form.issueDate}
              mode="outlined"
              style={styles.input}
              left={<TextInput.Icon name="calendar-month" color="#244a85" />}
              onFocus={() => setOpenIssuePicker(true)}
            />
            <DatePickerModal
              locale="en"
              mode="single"
              visible={openIssuePicker}
              onDismiss={() => setOpenIssuePicker(false)}
              date={form.issueDate ? new Date(form.issueDate) : undefined}
              onConfirm={({ date }) => {
                setOpenIssuePicker(false);
                handleChange('issueDate', formatDate(date));
              }}
            />

            {/* Last Date Picker */}
            <TextInput
              label="✅ Last Date"
              value={form.lastDate}
              mode="outlined"
              style={styles.input}
              left={<TextInput.Icon name="calendar-check" color="#244a85" />}
              onFocus={() => setOpenLastPicker(true)}
            />
            <DatePickerModal
              locale="en"
              mode="single"
              visible={openLastPicker}
              onDismiss={() => setOpenLastPicker(false)}
              date={form.lastDate ? new Date(form.lastDate) : undefined}
              onConfirm={({ date }) => {
                setOpenLastPicker(false);
                handleChange('lastDate', formatDate(date));
              }}
            />

            {/* Employee Selection */}
            <View style={styles.assignHeader}>
              <IconButton icon="account-multiple" iconColor="#244a85" size={28} />
              <Text variant="titleMedium" style={styles.subheading}>
                Assign to Employees
              </Text>
            </View>
            <View style={styles.checkboxGroup}>
              {employees.map((emp) => (
                <View key={emp.id} style={styles.checkboxContainer}>
                  <Checkbox
                    status={selectedEmployees.includes(emp.id) ? 'checked' : 'unchecked'}
                    onPress={() => toggleEmployeeSelection(emp.id)}
                    color="#ff6f61"
                    uncheckedColor="#bbb"
                  />
                  <Text style={styles.labelText}>
                    👤 {emp.name} ({emp.department || 'No Dept'})
                  </Text>
                </View>
              ))}
            </View>

            {/* Add or Update Button */}
            <Button
              mode="contained"
              onPress={handleAddOrUpdateTask}
              style={styles.button}
              icon={editingTaskId ? 'pencil-circle' : 'plus-circle'}
              contentStyle={{ flexDirection: 'row-reverse' }}
            >
              {editingTaskId ? 'Update Task' : 'Add Task'}
            </Button>

            {/* Cancel Edit Button */}
            {editingTaskId && (
              <Button
                mode="outlined"
                onPress={resetForm}
                style={styles.button}
                icon="close-circle-outline"
                textColor="#e74c3c"
              >
                Cancel Edit
              </Button>
            )}

            <Divider style={styles.divider} />
          </>
        }

        // Render each task as a card
        renderItem={({ item }) => (
          <Card style={styles.card} elevation={8}>
            <Card.Title title={`📝 ${item.title}`} titleStyle={styles.cardTitle} />
            <Card.Content>
              {/* Task Fields */}
              <View style={styles.taskInfoRow}>
                <IconButton icon="text-box-outline" size={20} iconColor="#244a85" />
                <Text style={styles.taskValue}>{item.description}</Text>
              </View>
              <View style={styles.taskInfoRow}>
                <IconButton icon="calendar-month-outline" size={20} iconColor="#244a85" />
                <Text style={styles.taskValue}>Issue Date: {item.issueDate}</Text>
              </View>
              <View style={styles.taskInfoRow}>
                <IconButton icon="calendar-check-outline" size={20} iconColor="#244a85" />
                <Text style={styles.taskValue}>Last Date: {item.lastDate}</Text>
              </View>
              <View style={styles.taskInfoRow}>
                <IconButton icon="account-multiple-outline" size={20} iconColor="#244a85" />
                <Text style={styles.taskValue}>Assigned: {getEmployeeNames(item.assignedTo)}</Text>
              </View>
            </Card.Content>
            <Card.Actions>
              {/* Edit and Delete Buttons */}
              <IconButton icon="pencil-circle" onPress={() => handleEditTask(item)} iconColor="#244a85" />
              <IconButton icon="delete-circle" onPress={() => handleDeleteTask(item.id)} iconColor="#e74c3c" />
            </Card.Actions>
          </Card>
        )}
        ListEmptyComponent={<Text style={styles.emptyText}>No tasks added yet.</Text>}
      />
    </>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 16,
    backgroundColor: '#fff',
  },
  heading: {
    marginBottom: 10,
    fontWeight: '900',
    color: '#1E3A8A',
  },
  subheading: {
    marginVertical: 10,
    fontWeight: '700',
    color: '#1E3A8A',
  },
  input: {
    marginBottom: 12,
    backgroundColor: '#f0f0f0',
  },
  labelText: {
    color: '#000',
    marginLeft: 8,
    fontSize: 16,
  },
  checkboxGroup: {
    marginBottom: 20,
    backgroundColor: '#f0f0f0',
    padding: 10,
    borderRadius: 8,
  },
  checkboxContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 5,
  },
  button: {
    marginVertical: 10,
    borderRadius: 6,
    backgroundColor: '#244a85',
  },
  card: {
    marginBottom: 12,
    backgroundColor: '#f0f0f0',
    borderRadius: 10,
  },
  cardTitle: {
    fontWeight: '700',
    color: '#1E3A8A',
  },
  taskInfoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 6,
  },
  taskValue: {
    color: '#000',
    marginLeft: 6,
    fontSize: 14,
  },
  emptyText: {
    textAlign: 'center',
    marginTop: 20,
    color: '#ccc',
  },
  assignHeader: {
    flexDirection: 'row',
    alignItems: 'center',
  },
});

export default TaskScreen;
